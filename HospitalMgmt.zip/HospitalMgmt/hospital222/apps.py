from django.apps import AppConfig


class Hospital222Config(AppConfig):
    name = 'hospital222'
